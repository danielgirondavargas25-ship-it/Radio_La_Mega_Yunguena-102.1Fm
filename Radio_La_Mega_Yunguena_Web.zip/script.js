const audio = document.getElementById('radioAudio');
const playButton = document.getElementById('playButton');
const playIcon = document.getElementById('playIcon');
const playerTitle = document.getElementById('playerTitle');
const playerStatus = document.getElementById('playerStatus');
const soundBars = document.querySelector('.sound-bars');

function setPlaying(playing) {
  playIcon.textContent = playing ? 'Ⅱ' : '▶';
  playButton.setAttribute('aria-label', playing ? 'Pausar radio' : 'Reproducir radio');
  playerTitle.textContent = playing ? 'Estás escuchando La Mega Yungueña' : 'Dale play y vive La Mega';
  playerStatus.textContent = playing ? 'Señal en directo · 102.1 FM' : 'Listos para conectarte con nuestra señal';
  soundBars.classList.toggle('active', playing);
}

playButton.addEventListener('click', async () => {
  if (!audio.paused) {
    audio.pause();
    setPlaying(false);
    return;
  }
  playerTitle.textContent = 'Conectando con la radio…';
  playerStatus.textContent = 'Un momento, estamos buscando la señal';
  try {
    await audio.play();
    setPlaying(true);
  } catch (error) {
    setPlaying(false);
    playerTitle.textContent = 'No se pudo iniciar la señal';
    playerStatus.textContent = 'Comprueba tu conexión y vuelve a intentarlo.';
  }
});

audio.addEventListener('playing', () => setPlaying(true));
audio.addEventListener('pause', () => setPlaying(false));
audio.addEventListener('error', () => {
  setPlaying(false);
  playerTitle.textContent = 'Señal temporalmente no disponible';
  playerStatus.textContent = 'Intenta de nuevo en unos instantes.';
});

const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuToggle.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(opened));
  menuToggle.textContent = opened ? '×' : '☰';
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.textContent = '☰';
}));
document.getElementById('year').textContent = new Date().getFullYear();
